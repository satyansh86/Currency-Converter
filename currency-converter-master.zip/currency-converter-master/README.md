# Build a Currency Converter with React JS and Tailwind CSS
## [Click Here to Watch Full tutorial on Youtube](https://www.youtube.com/watch?v=Y1Q4XXXmVk4)

![currency convertor](https://github.com/piyush-eon/currency-converter/assets/51760520/17077560-f167-4291-aeb9-069f281f3406)
